package com.example.aatif.project;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class showalldata extends AppCompatActivity {
Button clk;
DatabaseHelper mydb;
TextView  txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showalldata);
        mydb=new DatabaseHelper(this);
        clk=(Button)findViewById(R.id.sad);
        showAllData();
    }
    public void showAllData(){
        clk.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor ans = mydb.getdata();
                        if (ans.getCount() == 0) {
                            showmessage("Error","No data found");
                            return;
                        }
                        StringBuffer str = new StringBuffer();
                        while (ans.moveToNext()) {
                            str.append("ID:" + ans.getString(0) + "\n");
                            str.append("Name:" + ans.getString(1) + "\n");
                            str.append("Email:" + ans.getString(2) + "\n");
                            str.append("Contact:" + ans.getString(3) + "\n");
                            str.append("Password:" + ans.getString(4) + "\n");
                            showmessage("Data",str.toString());
                        }


                    }
                }
        );
    }
    public void showmessage(String title,String msg){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }
    public void logout(View v){
        Intent i=new Intent(showalldata.this,MainActivity.class);
        startActivity(i);
    }
}
