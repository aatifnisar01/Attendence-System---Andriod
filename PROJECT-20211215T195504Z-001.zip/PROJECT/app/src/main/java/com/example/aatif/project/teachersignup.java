package com.example.aatif.project;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class teachersignup extends Activity {
    DatabaseHelper mydb;
    EditText ed1, ed2, ed3, ed4;
    Button bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachersignup);
        mydb = new DatabaseHelper(this);
        ed1 = (EditText) findViewById(R.id.edname);
        ed2 = (EditText) findViewById(R.id.edemail);
        ed3 = (EditText) findViewById(R.id.edcontact);
        ed4 = (EditText) findViewById(R.id.edpwd);
        bt = (Button) findViewById(R.id.signup);
        Add_data();
    }

    public void Add_data() {
        bt.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (((ed1.getText().toString()).equals("")) || ((ed2.getText().toString()).equals("")) || ((ed3.getText().toString()).equals("")) || (ed4.getText().toString().equals("")))
                        {
                            Toast.makeText(getApplicationContext(), "DATA not inserted", Toast.LENGTH_SHORT).show();
                        } else {
                            boolean ans = mydb.InsertData(ed1.getText().toString(), ed2.getText().toString(), ed3.getText().toString(), ed4.getText().toString());

                            if (ans == true)

                                Toast.makeText(getApplicationContext(), "DATA INSERTED", Toast.LENGTH_SHORT).show();
                            Intent i =new Intent(teachersignup.this,teacherlogin.class);
                            startActivity(i);
                        }
                    }
                });

    }
}
