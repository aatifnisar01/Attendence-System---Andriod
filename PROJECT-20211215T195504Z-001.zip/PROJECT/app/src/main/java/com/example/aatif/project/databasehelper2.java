package com.example.aatif.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class databasehelper2 extends SQLiteOpenHelper {
    public static final String DATABASE_NAME1 = "adddetails.db";
    public static final String TABLE_NAME1 = "attendance";
    public static final String col6 = "ID";
    public static final String col7 = "addname";

    public databasehelper2(Context context) {
        super(context, DATABASE_NAME1, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
db.execSQL("CREATE TABLE "+TABLE_NAME1+"(ID INTEGER PRIMARY KEY AUTOINCREMENT,ADDNAME TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
db.execSQL("DROP TABLE IF EXISTS " +TABLE_NAME1);
onCreate(db);
    }

    public boolean InsertData2(String addname) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col7, addname);
        long res2 = db.insert(TABLE_NAME1, null, cv);
        if (res2 == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor getdata2() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT  * FROM " + TABLE_NAME1;
        Cursor res = db.rawQuery(query, null);
        if (res != null)
            res.moveToFirst();
        return res;
    }
}

