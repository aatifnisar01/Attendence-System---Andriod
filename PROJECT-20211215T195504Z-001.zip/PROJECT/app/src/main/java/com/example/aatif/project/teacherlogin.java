package com.example.aatif.project;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;

public class teacherlogin extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacherlogin);
    }
public void onclick6(View v){
    Intent i=new Intent(teacherlogin.this,afterlogin.class);
    startActivity(i);
}
}
