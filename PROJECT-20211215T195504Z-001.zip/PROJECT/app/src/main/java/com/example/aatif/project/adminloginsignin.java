package com.example.aatif.project;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class adminloginsignin extends AppCompatActivity {
EditText ed1,ed2;
Button clk;
int counter=3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminloginsignin);
        ed1=(EditText)findViewById(R.id.edusn);
     clk=(Button)findViewById(R.id.butadmin);
        ed2=(EditText)findViewById(R.id.edusn2);
    }
    public void admin(View v){
        String str1=ed1.getText().toString();
        String str2=ed2.getText().toString();
        if((str1.equals("mba1234"))&&(str2.equals("mba1234"))){
        Intent i =new Intent(adminloginsignin.this,showalldata.class);
        startActivity(i);}
        else  if((str1.equals(""))||(str2.equals(""))){
            Toast.makeText(getApplicationContext(),"Enter both username and password",Toast.LENGTH_SHORT).show();
            counter--;
        }
        else {
            Toast.makeText(getApplicationContext(),"Enter correct values",Toast.LENGTH_SHORT).show();
           counter--;
        }
        if(counter==0){
            clk.setEnabled(false);
            Toast.makeText(getApplicationContext(),"You have reached the number of attempts",Toast.LENGTH_SHORT).show();
            }

    }
}
