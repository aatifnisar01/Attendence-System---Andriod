package com.example.aatif.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "signup.db";
    public static final String TABLE_NAME = "SignupName";
    public static final String col1 = "ID";
    public static final String col2 = "Name";
    public static final String col3 = "Email";
    public static final String col4 = "Contact";
    public static final String col5 = "Password";

    public DatabaseHelper(Context context)

    {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create Table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,EMAIL TEXT,CONTACT INTEGER,PASSWORD TEXT,ADDNAME TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }

    public boolean InsertData(String name, String email, String contact, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col2, name);
        cv.put(col3, email);
        cv.put(col4, contact);
        cv.put(col5, password);

        long res = db.insert(TABLE_NAME, null, cv);

        if (res == -1) {
            return false;
        } else {
            return true;
        }
    }



    public Cursor getdata() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor res = db.rawQuery(query, null);
        if (res != null)
            res.moveToFirst();
        return res;
    }
}