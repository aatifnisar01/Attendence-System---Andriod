package com.example.aatif.project;

import android.database.Cursor;
import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class adddetails extends Activity {
    databasehelper2 mydb2;
    ListView lvuse;
    ArrayList<String> ListData;
    ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adddetails);

        lvuse=(ListView)findViewById(R.id.lv);
        mydb2=new databasehelper2(this);
        populateListView();
    }
    private void populateListView(){
        Cursor data=mydb2.getdata2();

        ListData=new ArrayList<>();
        while (data.moveToNext()){
            ListData.add(data.getString(1));
        }
        adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,ListData);
        lvuse.setAdapter(adapter);
    }

}
