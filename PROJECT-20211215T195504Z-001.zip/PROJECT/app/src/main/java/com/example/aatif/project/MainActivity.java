package com.example.aatif.project;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    View layout;
    LayoutInflater li;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        li = getLayoutInflater();
        layout=li.inflate(R.layout.customtoast,(ViewGroup)findViewById(R.id.customT));
        Toast t=new Toast(getApplicationContext());
        t.setDuration(Toast.LENGTH_LONG);
        t.setGravity(Gravity.CENTER_VERTICAL,0,0);
        t.setView(layout);
        t.show();
    }

    public void onclick1(View v) {
        Intent i = new Intent(MainActivity.this, teacherdesk.class);
        startActivity(i);
    }

    public void onclick3(View v) {
        Intent i = new Intent(MainActivity.this, adminloginsignin.class);
        startActivity(i);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.muskan) {
            Intent i = new Intent();
            i.setAction(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://www.instagram.com/meshakapoor/"));
            startActivity(i);
        }
        if (id == R.id.aatif) {

            Intent i = new Intent();
            i.setAction(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://www.instagram.com/aatifnisar01/"));
            startActivity(i);

        }
        if (id == R.id.bhavya) {
            Intent i = new Intent();
            i.setAction(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://www.instagram.com/_bhavyabatra_/"));
            startActivity(i);

        }
        if (id == R.id.help) {
            Toast.makeText(getApplicationContext(), "We Wont Help :/", Toast.LENGTH_SHORT).show();
        }
        return true;
    }
}