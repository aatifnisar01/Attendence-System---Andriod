package com.example.aatif.project;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class afterlogin extends Activity {
    databasehelper2 mydb2;
    EditText eduse;
    Button bt1;
    Button bt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afterlogin);
        eduse=(EditText)findViewById(R.id.edname);
        bt1=(Button)findViewById(R.id.enterd);
        bt2=(Button)findViewById(R.id.viewd);
        mydb2=new databasehelper2(this);

    bt1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String newEntry=eduse.getText().toString();
            if(eduse.length()!=0){
                Adddata(newEntry);
                eduse.setText("");
            }
            else {
                Toastmsg("Enter something");
            }
        }
    });
    bt2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(afterlogin.this,adddetails.class);
            startActivity(i);
        }
    });
    }

public void Adddata(String newEntry){
        boolean insertdata=mydb2.InsertData2(newEntry);
        if(insertdata){
            Toastmsg("Data inserted");
        }
        else
        {
            Toastmsg("Data Not Inserted");
        }
        }
    private void Toastmsg(String msg)
    {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

}
